//===----------------------------------------------------------------------===//
//
// This source file is part of the Swift Argument Parser open source project
//
// Copyright (c) 2026 Apple Inc. and the Swift project authors
// Licensed under Apache License v2.0 with Runtime Library Exception
//
// See https://swift.org/LICENSE.txt for license information
//
//===----------------------------------------------------------------------===//

import Foundation
import PackagePlugin

protocol GeneratePlugin: CommandPlugin {
  static var pluginName: String { get }
  static var executableName: String { get }
  static var artifactName: String { get }

  static func outputDirectory(
    context: PluginContext, target: SwiftSourceModuleTarget
  ) -> URL
}

extension GeneratePlugin {
  func performCommand(
    context: PluginContext,
    arguments: [String]
  ) async throws {
    // Locate generation tool.
    let generationTool = Self.executableName
    let generationToolFile = try context.tool(named: generationTool).url

    // Create an extractor to extract plugin-only arguments from the `arguments`
    // array.
    var extractor = ArgumentExtractor(arguments)

    // Run generation tool once if help is requested.
    if extractor.helpRequest() {
      try generationToolFile.exec(arguments: ["--help"])
      print(
        """
        ADDITIONAL OPTIONS:
          --configuration <configuration>
                      Tool build configuration used to generate the
                      reference document. (default: release)

        NOTE: The "\(Self.pluginName)" plugin handles passing the "<tool>" and
        "--output-directory <output-directory>" arguments. Manually supplying
        these arguments will result in a runtime failure.
        """)
      return
    }

    // Extract configuration argument before making it to the
    // "generate-docc-reference" tool.
    let configuration = try extractor.configuration()

    // Build all products first.
    print("Building package in \(configuration) mode...")
    let buildResult = try packageManager.build(
      .all(includingTests: false),
      parameters: .init(configuration: configuration))

    guard buildResult.succeeded else {
      throw GeneratePluginError.buildFailed(buildResult.logText)
    }
    print("Built package in \(configuration) mode")

    // Run generate-docc-reference on all executable artifacts.
    for builtArtifact in buildResult.builtArtifacts {
      // Skip non-executable targets
      guard builtArtifact.kind == .executable else { continue }

      // Skip executables without a matching product.
      guard let product = builtArtifact.matchingProduct(context: context)
      else { continue }

      // Skip products without a dependency on ArgumentParser.
      guard product.hasDependency(named: "ArgumentParser") else { continue }

      // Skip products with multiple underlying targets.
      guard product.targets.count == 1 else { continue }
      let target = product.targets[0]

      // Skip non swift source targets.
      guard let target = target as? SwiftSourceModuleTarget else { continue }

      // Get the artifacts name.
      let executableName = builtArtifact.url.lastPathComponent
      print("Generating \(Self.artifactName) for \(executableName)...")

      // Create output directory.
      let outputDirectory = Self.outputDirectory(
        context: context, target: target)
      try outputDirectory.createOutputDirectory()

      // Create generation tool arguments.
      var generationToolArguments = [
        builtArtifact.url.path(percentEncoded: false),
        "--output-directory",
        outputDirectory.path(percentEncoded: false),
      ]
      generationToolArguments.append(
        contentsOf: extractor.remainingArguments)

      // Spawn generation tool.
      try generationToolFile.exec(arguments: generationToolArguments)
      print("Generated \(Self.artifactName) in '\(outputDirectory)'")
    }
  }
}
